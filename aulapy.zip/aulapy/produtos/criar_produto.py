from repositorios import produtos_repositorios

codigo_atual = 1

def add_produto(nome: str, preco: float, qtd_disponivel: int):
    global codigo_atual
    codigo_atual += 1
    novo_produto = {
        "codigo": codigo_atual,
        "nome": nome,
        "preco": preco,
        "qtd_disponivel": qtd_disponivel,
        "disponivel": True
    }
    produtos_repositorios.append(novo_produto)
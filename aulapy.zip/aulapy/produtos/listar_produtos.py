from repositorios import produtos_repositorios

def listar_produtos():
    print('-- PRODUTOS CADASTRADOS')
    for produto in produtos_repositorios:
        print(f"Código: {produto['codigo']}")
        print(f"Nome: {produto['nome']}")
        print(f"Preço: {produto['preco']}")
        print(f"Quantidade: {produto['qtd_disponivel']}")
        print(f"Ativo: {produto['disponível']}")
        print('-'*30)

        
produtos_repositorios = [
    {
        "codigo": 1,
        "nome": "mouse",
        "preco": 120.00,
        "qtd_disponivel": 10,
        "disponivel": True
    }
]
clientes_repositorio = [
    {
        "codigo": 1,
        "nome": "Leticia",
        "disponivel": True
    }
]
pedidos_repositorio = [
    {
        "codigo": 1,
        "codigo_cliente": 1,
        "produtos": [
            {
                "nome": "mouse",
                "quantidade": 2
            }
        ],
        "total": 240.00
    }
]
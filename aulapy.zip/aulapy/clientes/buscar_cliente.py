from repositorios import clientes_repositorio

def buscar_cliente_por_cod(codigo: int):
    for cliente in clientes_repositorio:
        if cliente['codigo'] == codigo:
            return cliente
    return None

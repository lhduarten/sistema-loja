from repositorios import clientes_repositorio

def listar_todos_clientes():
    print('--- CLIENTES CADASTRADOS ---')
    for cliente in clientes_repositorio:
        print(f"Código: {cliente['codigo']}")
        print(f"Nome: {cliente['nome']}")
        print(f"Ativo: {cliente['disponível']}")
        print('-'*30)
from repositorios import clientes_repositorio
from buscar_cliente import buscar_cliente_por_cod

def alterar_cliente(codigo: int, nome: str):
    cliente = buscar_cliente_por_cod(codigo)
    if cliente:
        cliente['nome'] = nome
        return cliente
    return None

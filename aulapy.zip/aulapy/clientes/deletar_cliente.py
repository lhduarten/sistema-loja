from .buscar_cliente import buscar_cliente_por_cod
from repositorios import clientes_repositorio

def remover_cliente(codigo: int):
    cliente = buscar_cliente_por_cod(codigo)
    if cliente:
        clientes_repositorio.remove(cliente)
        return {}
    return None
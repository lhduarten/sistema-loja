from repositorios import clientes_repositorio

codigo_atual = 1

def add_cliente(nome: str):
    global codigo_atual
    codigo_atual += 1
    novo_cliente = {
        "codigo": codigo_atual,
        "nome": nome,
        "disponivel": True
    }
    clientes_repositorio.append(novo_cliente)


if __name__ == '__main__':
    add_cliente('Luiz')
    print(clientes_repositorio)

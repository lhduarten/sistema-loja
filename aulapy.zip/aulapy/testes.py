from repositorios import *
from clientes.criar_cliente import add_cliente
from clientes.listar_clientes import listar_todos_clientes
from clientes.buscar_cliente import buscar_cliente_por_cod
from clientes.editar_clientes import alterar_cliente
from clientes.deletar_cliente import remover_cliente
from produtos.criar_produto import add_produto
from produtos.listar_produtos import listar_produtos



def test_add_cliente():
    add_cliente('Jonas')
    print(clientes_repositorio)

def test_listar_todos_clientes():
    listar_todos_clientes()

def test_buscar_cliente_por_cod():
    print(buscar_cliente_por_cod(1))
    print(buscar_cliente_por_cod(100)) #None

def test_alterar_cliente():
    print(alterar_cliente(1, 'Lucas'))
    print(alterar_cliente(0, 'Manoel'))

def test_remover_cliente():
    print(remover_cliente(1))
    print(remover_cliente(100))

def test_add_produtos():
    add_produto("teclado", 220.00, 10)
    print(produtos_repositorios)

def test_listar_produtos():
    listar_produtos()

if __name__ == '__main__':
    test_listar_todos_clientes()